This directory contains the C source files for a Brill emulator.
To generate the emulator, simply type

  make

This will generate an executable called brill which takes the name
of an Brill file as its command line argument.

The generation has been tested in April 2017 on the MSE server

  dimefox.eng.unimelb.edu.au

